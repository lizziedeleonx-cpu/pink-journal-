package com.pinkjournal.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Blush = Color(0xFFFFE6EF)
private val Rose = Color(0xFFB85C83)
private val Cream = Color(0xFFFFFAF5)
private val Ink = Color(0xFF633D50)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        setContent { PinkJournalApp() }
    }
}

data class Entry(val title: String, val body: String, val date: String, val imageUri: String = "")

@Composable
fun PinkJournalApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Inicio") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(loadEntries(context)) }
    var letter by remember { mutableStateOf("") }
    var reminderHour by remember { mutableStateOf("20") }
    var reminderMinute by remember { mutableStateOf("00") }
    var status by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        imageUri = uri?.toString() ?: ""
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = if (granted) "¡Permiso concedido! 💗" else "Activa las notificaciones en los ajustes de Android."
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Rose, onPrimary = Color.White, secondary = Color(0xFFD78EAB),
            background = Cream, surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Inicio", "Diario", "Cartitas", "Recordatorios").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Inicio" -> Icons.Default.Favorite
                                        "Diario" -> Icons.Default.MenuBook
                                        "Cartitas" -> Icons.Default.Mail
                                        else -> Icons.Default.Notifications
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("♡ pink journal ♡", color = Rose, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es")).format(Date()).replaceFirstChar { it.uppercase() },
                        color = Ink.copy(alpha = .7f))
                }
                when (tab) {
                    "Inicio" -> {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Blush), shape = RoundedCornerShape(26.dp)) {
                                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Un mensajito para ti 🎀", color = Rose, fontWeight = FontWeight.Bold)
                                    Text(dailyMessage(), color = Ink, style = MaterialTheme.typography.titleMedium)
                                    Text("Respira, bonita. Tu proceso también merece ternura. ♡", color = Rose)
                                }
                            }
                        }
                        item {
                            Card(shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("Tu rinconcito", style = MaterialTheme.typography.titleLarge, color = Rose)
                                    Text("Guarda recuerdos, escribe lo que sientes y date permiso para ir a tu ritmo.")
                                    Button(onClick = { tab = "Diario" }, modifier = Modifier.padding(top = 8.dp)) { Text("Escribir en mi diario") }
                                }
                            }
                        }
                    }
                    "Diario" -> {
                        item {
                            Card(shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Una página para ti 🌷", style = MaterialTheme.typography.titleLarge, color = Rose)
                                    OutlinedTextField(title, { title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    OutlinedTextField(body, { body = it }, label = { Text("¿Qué tienes en el corazón?") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                                    OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                                        Spacer(Modifier.width(8.dp)); Text(if (imageUri.isBlank()) "Añadir una foto" else "Foto seleccionada ♡")
                                    }
                                    Button(
                                        onClick = {
                                            if (title.isNotBlank() || body.isNotBlank()) {
                                                val date = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("es")).format(Date())
                                                entries = listOf(Entry(title.ifBlank { "Un recuerdo" }, body, date, imageUri)) + entries
                                                saveEntries(context, entries)
                                                title = ""; body = ""; imageUri = ""
                                                status = "Tu recuerdo quedó guardado en este teléfono. 💗"
                                            } else status = "Escribe algo antes de guardar."
                                        }, modifier = Modifier.fillMaxWidth()
                                    ) { Text("Guardar mi recuerdo ♡") }
                                }
                            }
                        }
                        if (status.isNotBlank()) item { Text(status, color = Rose) }
                        items(entries) { entry ->
                            Card(shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(entry.title, style = MaterialTheme.typography.titleMedium, color = Rose, fontWeight = FontWeight.Bold)
                                    Text(entry.date, style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = .65f))
                                    if (entry.body.isNotBlank()) Text(entry.body, modifier = Modifier.padding(top = 6.dp), color = Ink)
                                    if (entry.imageUri.isNotBlank()) Text("📷 Foto adjunta", color = Rose)
                                }
                            }
                        }
                    }
                    "Cartitas" -> {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Blush), shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Cartitas para mí 💌", style = MaterialTheme.typography.titleLarge, color = Rose)
                                    Text("No tienes que tenerlo todo resuelto. Estás aprendiendo, creciendo y mereces hablarte con cariño. Los pequeños pasos también cuentan. ♡", color = Ink)
                                    Divider(color = Rose.copy(alpha = .25f))
                                    Text("Escríbete una carta para volver a leerla cuando la necesites.", color = Rose)
                                    OutlinedTextField(letter, { letter = it }, label = { Text("Querida yo…") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
                                    Button(onClick = {
                                        val updated = entries + Entry("Una carta para mí", letter, SimpleDateFormat("d MMM yyyy", Locale("es")).format(Date()))
                                        entries = updated
                                        saveEntries(context, entries)
                                        letter = ""; status = "Tu cartita se guardó en tu diario. 💗"
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Guardar mi cartita") }
                                }
                            }
                        }
                        if (status.isNotBlank()) item { Text(status, color = Rose) }
                    }
                    else -> {
                        item {
                            Card(shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Recordatorio diario 🎀", style = MaterialTheme.typography.titleLarge, color = Rose)
                                    Text("Elige a qué hora quieres recibir tu mensajito bonito.")
                                    OutlinedTextField(reminderHour, { reminderHour = it.filter(Char::isDigit).take(2) }, label = { Text("Hora (0–23)") }, singleLine = true)
                                    OutlinedTextField(reminderMinute, { reminderMinute = it.filter(Char::isDigit).take(2) }, label = { Text("Minuto (0–59)") }, singleLine = true)
                                    Button(onClick = {
                                        val h = reminderHour.toIntOrNull()
                                        val m = reminderMinute.toIntOrNull()
                                        if (h == null || m == null || h !in 0..23 || m !in 0..59) {
                                            status = "Escribe una hora válida, por ejemplo 20 y 00."
                                        } else {
                                            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                            }
                                            scheduleDailyReminder(context, h, m)
                                            status = "¡Recordatorio diario programado para %02d:%02d! 💗".format(h, m)
                                        }
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Programar mensajito diario") }
                                    Text("Android puede retrasar avisos por ahorro de batería o restricciones del sistema.", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = .65f))
                                }
                            }
                        }
                        if (status.isNotBlank()) item { Text(status, color = Rose) }
                    }
                }
            }
        }
    }
}

private fun dailyMessage(): String {
    val messages = listOf(
        "No tienes que tenerlo todo resuelto. Un pasito a la vez también es avanzar. 🌷",
        "Háblate con la misma ternura que le darías a alguien que amas. 💗",
        "Descansar no te hace menos valiosa. Tú también mereces calma. 🎀",
        "Celebra tus pequeños logros; también forman parte de tus sueños. ✨",
        "Hoy puedes volver a empezar con paciencia y cariño hacia ti. 💌",
        "No necesitas ser perfecta para sentir orgullo de ti misma. ♡",
        "Tu ritmo es válido. Respira, bonita, y sigue cuando estés lista. 🌸"
    )
    val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    return messages[day % messages.size]
}

private fun loadEntries(context: Context): List<Entry> {
    return try {
        val raw = context.getSharedPreferences("pink_journal", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Entry(o.optString("title"), o.optString("body"), o.optString("date"), o.optString("imageUri"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveEntries(context: Context, entries: List<Entry>) {
    val arr = JSONArray()
    entries.forEach {
        arr.put(JSONObject().put("title", it.title).put("body", it.body).put("date", it.date).put("imageUri", it.imageUri))
    }
    context.getSharedPreferences("pink_journal", Context.MODE_PRIVATE).edit().putString("entries", arr.toString()).apply()
}

private fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel("pink_daily", "Mensajitos de Pink Journal", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "Tu mensajito bonito diario"
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun scheduleDailyReminder(context: Context, hour: Int, minute: Int) {
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(context, 741, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.setRepeating(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val open = PendingIntent.getActivity(context, 742, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "pink_daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Un mensajito para ti 🎀")
            .setContentText("Respira, bonita. Tu proceso también merece ternura. ♡")
            .setStyle(NotificationCompat.BigTextStyle().bigText("No tienes que tenerlo todo resuelto. Un pasito a la vez también es avanzar. 💗"))
            .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            manager.notify(741, notification)
        }
    }
}
